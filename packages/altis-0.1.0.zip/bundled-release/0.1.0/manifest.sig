{
  "typ": "altis-release/1",
  "kid": "arsya-rel-1",
  "alg": "Ed25519",
  "sig": "fOBDwlIO-PPM1latkuEGp902-3rkj4d92anM3IpQkZfqpZzKhkxgewxkg7NSX5thvHstDia4Ehdy9u7aJ6hDBg"
}
